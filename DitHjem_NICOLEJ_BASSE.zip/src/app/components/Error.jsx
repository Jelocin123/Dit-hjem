
import React from 'react'

const Error = ( {error} ) => {
  return (
    <div>Der er sket en fejl ... {error} </div>
  )
}

export default Error;